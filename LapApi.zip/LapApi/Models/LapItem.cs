namespace LapApi.Models
{
    public class LapItem
    {
        public long Id { get; set; }
        public string? Name { get; set; }
         public string? carno { get; set; }
          public string? time { get; set; }
        public bool IsComplete { get; set; }
    }
}