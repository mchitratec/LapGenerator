using System.ComponentModel.DataAnnotations;
namespace LapApi.Models
{
    public class LapItem
    {
        public long Id { get; set; }
        public string? Name { get; set; }
        [Required]
         public string? carno { get; set; }
         [Required]
          public string? time { get; set; }
          [Range(0, 999)]
        public bool IsComplete { get; set; }
    }
}