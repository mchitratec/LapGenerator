using Microsoft.EntityFrameworkCore;
using System.Diagnostics.CodeAnalysis;

namespace LapApi.Models
{
    public class LapContext : DbContext
    {
        public LapContext(DbContextOptions<LapContext> options)
            : base(options)
        {
        }

        public DbSet<LapItem> Lapitems { get; set; } = null!;
    }
}